package com.example.appcalculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtValor1, edtValor2;
    Button btnSoma, btnSubtrai, btnMulti, btnDividi;
    TextView txtR1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtValor1.findViewById(R.id.edtValor1);
        edtValor2.findViewById(R.id.edtValor2);
        btnSoma.findViewById(R.id.btnSomar);
        btnSubtrai.findViewById(R.id.btnSubtrair);
        btnMulti.findViewById(R.id.btnMultiplicar);
        btnDividi.findViewById(R.id.btnDividir);
        txtR1.findViewById(R.id.txtResultado);

        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double Valor1, Valor2, result1;
                try {
                    Valor1 = Double.parseDouble(edtValor1.getText().toString());
                    Valor2 = Double.parseDouble(edtValor2.getText().toString());
                    result1 = Valor1 + Valor2;

                    txtR1.setText("" + result1);
                } catch (NumberFormatException e) {
                    Toast.makeText(view.getContext(),
                            "Por favor, preencha ambos os campos corretamente", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSubtrai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double Valor1, Valor2, result1;
                try {
                    Valor1 = Double.parseDouble(edtValor1.getText().toString());
                    Valor2 = Double.parseDouble(edtValor2.getText().toString());
                    result1 = Valor1 - Valor2;

                    txtR1.setText("" + result1);
                } catch (NumberFormatException e) {
                    Toast.makeText(view.getContext(),
                            "Por favor, preencha ambos os campos corretamente", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double Valor1, Valor2, result1;
                try {
                    Valor1 = Double.parseDouble(edtValor1.getText().toString());
                    Valor2 = Double.parseDouble(edtValor2.getText().toString());
                    result1 = Valor1 * Valor2;

                    txtR1.setText("" + result1);
                } catch (NumberFormatException e) {
                    Toast.makeText(view.getContext(),
                            "Por favor, preencha ambos os campos corretamente", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDividi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double Valor1, Valor2, result1;
                try {
                    Valor1 = Double.parseDouble(edtValor1.getText().toString());
                    Valor2 = Double.parseDouble(edtValor2.getText().toString());
                    result1 = Valor1 / Valor2;

                    txtR1.setText("" + result1);
                } catch (NumberFormatException e) {
                    Toast.makeText(view.getContext(),
                            "Por favor, preencha ambos os campos corretamente", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}